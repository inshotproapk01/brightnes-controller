chrome.runtime.onInstalled.addListener(() => {
    console.log("Brightness Control extension installed.");
});
