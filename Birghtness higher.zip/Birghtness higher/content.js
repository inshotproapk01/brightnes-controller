	function increaseBrightness() {
	  document.body.style.filter = 'brightness(150%)';
	}

	increaseBrightness();
