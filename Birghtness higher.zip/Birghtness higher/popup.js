// Wait until the DOM content is fully loaded before adding event listeners
document.addEventListener('DOMContentLoaded', function () {
    const brightnessInput = document.getElementById("brightness");
    const brightnessValue = document.getElementById("brightnessValue");

    // Update brightness value when the input slider changes
    brightnessInput.addEventListener("input", function () {
        // Display the current value as a percentage next to the slider
        brightnessValue.textContent = `${brightnessInput.value}%`;

        // Get the current active tab and inject the brightness change
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: setBrightness,
                args: [brightnessInput.value]
            });
        });
    });

    // Function to set the brightness level on the webpage
    function setBrightness(value) {
        document.body.style.filter = `brightness(${value}%)`;
    }
});
